/* 
Remove Clozes Add-on for Anki


Copyright (C) 2016-2022  Aristotelis P. <https//glutanimate.com/>


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version, with the additions
listed at the end of the accompanied license file.


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.


You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.


NOTE: This program is subject to certain additional terms pursuant to
Section 7 of the GNU Affero General Public License.  You should have
received a copy of these additional terms immediately following the
terms and conditions of the GNU Affero General Public License which
accompanied this program.


If not, please request a copy through one of the means of contact
listed here: <https://glutanimate.com/contact/>.


Any modifications to this file must keep this entire header intact.
*/

/* Modified by https://github.com/athulkrishna2015/ on 2025‑11‑02: 
   Implemented cursor‑aware, nested‑safe cloze removal with native undo. */

/*
Cursor-aware, nested-safe cloze remover with native undo
- Removes only the innermost cloze that encloses the cursor (or selection start)
- Correctly skips nested {{c…::…}} while finding the matching }}
- Drops optional ::hint/comments
- Uses a single insertHTML command to create one undo step
- Fix: if caret is on the opener {{cN::, delete that cloze, not the parent
*/

(function () {
  // ==========================================
  // 1. CONFIGURATION & STATE
  // ==========================================
  const removeClozesConfig = window.RemoveClozesConfig || {};
  const stripPastedClozesInNonClozeFields =
    removeClozesConfig.stripPastedClozesInNonClozeFields !== false;
  const reviewClozeFieldNames = Array.isArray(removeClozesConfig.reviewClozeFieldNames)
    ? new Set(removeClozesConfig.reviewClozeFieldNames)
    : null;
  let editorClozeFields = null;

  // ==========================================
  // 2. SHORTCUTS & HOTKEYS
  // ==========================================
  function parseShortcut(shortcut) {
    if (!shortcut || typeof shortcut !== "string") return null;
    const keys = shortcut.toLowerCase().split(/[+]/).map((k) => k.trim()).filter(Boolean);
    if (!keys.length) return null;
    const main = keys[keys.length - 1];
    const mod = {
      ctrl: keys.includes("ctrl") || keys.includes("cmd") || keys.includes("meta"),
      shift: keys.includes("shift"),
      alt: keys.includes("alt"),
      key: main,
    };
    return mod;
  }

  function shortcutMatches(event, parsed) {
    if (!parsed) return false;
    if ((event.ctrlKey || event.metaKey) !== parsed.ctrl) return false;
    if (!!event.shiftKey !== parsed.shift) return false;
    if (!!event.altKey !== parsed.alt) return false;

    const code = (event.code || "").toLowerCase();
    const key = (event.key || "").toLowerCase();
    const main = parsed.key;

    if (main.length === 1) {
      if (/[a-z]/.test(main)) return code === `key${main}` || key === main;
      if (/\d/.test(main)) return code === `digit${main}` || key === main;
      return key === main;
    }

    return key === main || code === main;
  }

  function isEFDRCEditingContext() {
    if (!window.EFDRC) return false;
    const active = document.activeElement;
    if (!active) return false;
    return !!active.closest("[data-EFDRCfield]");
  }

  function installReviewShortcutIfNeeded() {
    const parsed = parseShortcut(window.RemoveClozesHotkey);
    if (!parsed) return;
    if (window.__removeClozesReviewShortcutBound) return;

    window.addEventListener("keydown", function (event) {
      if (event.repeat) return;
      if (!isEFDRCEditingContext()) return;
      if (!shortcutMatches(event, parsed)) return;
      removeClozesInSelection();
      event.preventDefault();
      event.stopPropagation();
    }, true);

    window.__removeClozesReviewShortcutBound = true;
  }

  // ==========================================
  // 3. UTILITIES & HELPERS
  // ==========================================
  function interceptWindowFunction(name, beforeCall) {
    const wrap = function (fn) {
      if (typeof fn !== "function" || fn.__removeClozesWrapped) {
        return fn;
      }

      const wrapped = function (...args) {
        beforeCall(...args);
        return fn.apply(this, args);
      };
      wrapped.__removeClozesWrapped = true;
      return wrapped;
    };

    let current = wrap(window[name]);
    try {
      Object.defineProperty(window, name, {
        configurable: true,
        get() {
          return current;
        },
        set(value) {
          current = wrap(value);
        },
      });
    } catch (e) {
      if (typeof current === "function") {
        window[name] = current;
      }
    }
  }

  function decodeBase64Unicode(value) {
    if (!value) return "";
    try {
      return decodeURIComponent(
        window.atob(value)
          .split("")
          .map(function (char) {
            return `%${(`00${char.charCodeAt(0).toString(16)}`).slice(-2)}`;
          })
          .join("")
      );
    } catch (e) {
      return "";
    }
  }

  // ==========================================
  // 4. DOM & SELECTION HELPERS
  // ==========================================
  function getRootSelection(root) {
    return root && root.getSelection ? root.getSelection() : document.getSelection();
  }

  function canUseCommand(name) {
    return typeof document.queryCommandSupported === "function"
      ? document.queryCommandSupported(name)
      : true;
  }

  function collapseSelectionToEnd(selection) {
    if (selection && selection.collapseToEnd) {
      try {
        selection.collapseToEnd();
      } catch (e) {}
    }
  }

  function notifyInput(editable) {
    try {
      editable.dispatchEvent(new InputEvent("input", { bubbles: true }));
    } catch (e) {
      const evt = document.createEvent("Event");
      evt.initEvent("input", true, false);
      editable.dispatchEvent(evt);
    }
  }

  function getClosestMatchingNode(node, selector) {
    let current = node && node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    while (current) {
      if (current.matches && current.matches(selector)) {
        return current;
      }
      if (current.closest) {
        const match = current.closest(selector);
        if (match) return match;
      }
      const root = current.getRootNode ? current.getRootNode() : null;
      current = root && root.host ? root.host : null;
    }
    return null;
  }

  function getEditableFromEvent(event) {
    if (event && typeof event.composedPath === "function") {
      const path = event.composedPath();
      for (const node of path) {
        if (node && node.nodeType === Node.ELEMENT_NODE && node.isContentEditable) {
          return node;
        }
      }
    }

    const root = getActiveRoot();
    return getEditableDiv(root);
  }

  // ==========================================
  // 5. FIELD & CONTEXT CHECKING
  // ==========================================
  function editorFieldUsesClozeFilter(editable) {
    if (!Array.isArray(editorClozeFields)) return null;

    const container = getClosestMatchingNode(editable, ".field-container");
    if (!container) return null;

    const rawIndex = container.getAttribute("data-index") || "";
    const fieldIndex = Number.parseInt(rawIndex, 10);
    if (Number.isNaN(fieldIndex)) return null;
    return !!editorClozeFields[fieldIndex];
  }

  function reviewFieldUsesClozeFilter(editable) {
    if (!reviewClozeFieldNames) return null;

    const field = getClosestMatchingNode(editable, "[data-EFDRCfield]");
    if (!field) return null;

    const encodedFieldName = field.getAttribute("data-EFDRCfield");
    return reviewClozeFieldNames.has(decodeBase64Unicode(encodedFieldName));
  }

  function shouldStripPastedClozes(editable) {
    if (!stripPastedClozesInNonClozeFields || !editable) return false;

    const reviewFieldIsCloze = reviewFieldUsesClozeFilter(editable);
    if (reviewFieldIsCloze !== null) {
      return !reviewFieldIsCloze;
    }

    const editorFieldIsCloze = editorFieldUsesClozeFilter(editable);
    if (editorFieldIsCloze !== null) {
      return !editorFieldIsCloze;
    }

    return false;
  }

  function getActiveRoot() {
    const el = document.activeElement;
    if (!el) return document;
    return el.shadowRoot || document;
  }

  function getEditableDiv(root) {
    if (!root) return null;
    const active = root.activeElement || document.activeElement;
    if (active && active.isContentEditable) {
      return active;
    }
    return root.querySelector('[contenteditable="true"]');
  }

  // ==========================================
  // 6. SOURCE TEXT & MAPPING (MATHJAX)
  // ==========================================
  function getEditableSourceText(container) {
    let text = "";
    const walker = document.createTreeWalker(
      container,
      NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT,
      {
        acceptNode(node) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const tag = node.tagName.toUpperCase();
            if (tag === "ANKI-MATHJAX" || tag === "BR") return NodeFilter.FILTER_ACCEPT;
            return NodeFilter.FILTER_SKIP;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === Node.TEXT_NODE) {
        text += node.textContent;
      } else if (node.tagName.toUpperCase() === "ANKI-MATHJAX") {
        const formula = node.getAttribute("data-formula") || node.getAttribute("data-mathjax") || "";
        if (node.classList.contains("mjx-block")) {
          text += "\\[" + formula + "\\]";
        } else {
          text += "\\(" + formula + "\\)";
        }
      } else if (node.tagName.toUpperCase() === "BR") {
        text += "\n";
      }
    }
    return text;
  }

  function mapSourceIndexToNodeOffset(container, idx) {
    const walker = document.createTreeWalker(
      container,
      NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT,
      {
        acceptNode(node) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const tag = node.tagName.toUpperCase();
            if (tag === "ANKI-MATHJAX" || tag === "BR") return NodeFilter.FILTER_ACCEPT;
            return NodeFilter.FILTER_SKIP;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );

    let node;
    let remaining = idx;
    const nodes = [];
    while ((node = walker.nextNode())) {
      nodes.push(node);
    }

    for (const node of nodes) {
      let len = 0;
      const tag = node.nodeType === Node.ELEMENT_NODE ? node.tagName.toUpperCase() : "";
      if (node.nodeType === Node.TEXT_NODE) {
        len = node.textContent.length;
      } else if (tag === "ANKI-MATHJAX") {
        const formula = node.getAttribute("data-formula") || node.getAttribute("data-mathjax") || "";
        const delimLen = 4; // \( and \) or \[ and \]
        len = formula.length + delimLen;
      } else if (tag === "BR") {
        len = 1;
      }

      if (remaining < len) {
        if (node.nodeType === Node.TEXT_NODE) {
          return { node, offset: remaining };
        }
        if (tag === "ANKI-MATHJAX") {
          return { node, offset: remaining };
        }
        // For other atomic elements (BR), return position before/after based on remaining
        const parent = node.parentNode;
        const index = Array.from(parent.childNodes).indexOf(node);
        return { node: parent, offset: remaining === 0 ? index : index + 1 };
      }
      remaining -= len;
    }
    return { node: container, offset: container.childNodes.length };
  }

  function getCursorIndexInSource(container, selection) {
    if (!selection || selection.rangeCount === 0) return -1;

    let range = selection.getRangeAt(0);
    let node = range.startContainer;
    let offset = range.startOffset;

    // Handle Shadow DOM (Rendered MathJax)
    // Standard Ranges cannot cross shadow boundaries. If we are inside, we climb to host.
    let current = node;
    while (current && current !== container) {
      const root = current.getRootNode ? current.getRootNode() : null;
      if (root && root.nodeType === Node.DOCUMENT_FRAGMENT_NODE && root.host) {
        const host = root.host;
        if (host.tagName.toUpperCase() === "ANKI-MATHJAX") {
          // We are inside rendered math. Map cursor to just after \( delimiter.
          const lightRange = document.createRange();
          lightRange.setStartBefore(container.firstChild || container);
          lightRange.setEndBefore(host);
          const frag = lightRange.cloneContents();
          return getEditableSourceText(frag).length + 2;
        }
        current = host;
      } else {
        break;
      }
    }

    const preCaretRange = range.cloneRange();
    try {
      preCaretRange.setStartBefore(container.firstChild || container);
      preCaretRange.setEnd(node, offset);
    } catch (e) {
      return -1;
    }

    const frag = preCaretRange.cloneContents();
    return getEditableSourceText(frag).length;
  }

  // ==========================================
  // 7. STRING PARSING & CLOZE MATH
  // ==========================================
  function findAllClozeRanges(text) {
    const ranges = [];
    let i = 0;
    while (i < text.length) {
      if (text.toLowerCase().startsWith("{{c", i)) {
        const mm = text.slice(i).match(/^\{\{c\d+::/i);
        if (mm) {
          const start = i;
          let j = i + mm[0].length;
          let depth = 0;
          let hintStart = null;
          while (j < text.length) {
            if (depth === 0 && text.startsWith("::", j) && hintStart === null) {
              hintStart = j;
              j += 2;
              continue;
            }
            if (depth === 0 && text.startsWith("}}", j)) {
              ranges.push({
                openStart: start,
                textStart: start + mm[0].length,
                textEnd: hintStart !== null ? hintStart : j,
                closeEnd: j + 2,
              });
              i = j + 1; // outer loop will increment
              break;
            }
            const ch = text[j];
            if (ch === "{") depth++;
            else if (ch === "}" && depth > 0) depth--;
            j++;
          }
          if (j >= text.length) i = text.length;
        }
      }
      i++;
    }
    return ranges;
  }

  function findInnermostClozeAt(text, pos) {
    const all = findAllClozeRanges(text);
    const candidates = all.filter(r => pos >= r.openStart && pos <= r.closeEnd);
    if (!candidates.length) return null;
    return candidates.reduce((a, b) => (b.closeEnd - b.openStart < a.closeEnd - a.openStart ? b : a));
  }

  // ==========================================
  // 8. ACTION & REPLACEMENT LOGIC
  // ==========================================
  function unwrapClozeInContainerByBounds(container, bounds) {
    const { openStart, textStart, textEnd, closeEnd } = bounds;
    const innerStartPos = mapSourceIndexToNodeOffset(container, textStart);
    const innerEndPos = mapSourceIndexToNodeOffset(container, textEnd);
    const outerStartPos = mapSourceIndexToNodeOffset(container, openStart);
    const outerEndPos = mapSourceIndexToNodeOffset(container, closeEnd);

    const innerRange = document.createRange();
    innerRange.setStart(innerStartPos.node, innerStartPos.offset);
    innerRange.setEnd(innerEndPos.node, innerEndPos.offset);
    const innerFrag = innerRange.cloneContents();

    const outerRange = document.createRange();
    outerRange.setStart(outerStartPos.node, outerStartPos.offset);
    outerRange.setEnd(outerEndPos.node, outerEndPos.offset);

    outerRange.deleteContents();
    outerRange.insertNode(innerFrag);
    if (container.normalize) {
      container.normalize();
    }
    return true;
  }

  function removeAllClozesFromContainer(container) {
    let replaced = false;

    // First unwrap clozes inside MathJax elements
    const mathjaxElements = container.querySelectorAll("anki-mathjax");
    for (const el of mathjaxElements) {
      const formula = el.getAttribute("data-formula") || el.getAttribute("data-mathjax");
      if (formula && formula.toLowerCase().includes("{{c")) {
        const ranges = findAllClozeRanges(formula);
        if (ranges.length) {
          let newFormula = formula;
          ranges.sort((a, b) => b.openStart - a.openStart);
          for (const r of ranges) {
            newFormula = newFormula.slice(0, r.openStart) + 
                         newFormula.slice(r.textStart, r.textEnd) + 
                         newFormula.slice(r.closeEnd);
          }
          
          const newEl = el.cloneNode(true);
          newEl.setAttribute("data-formula", newFormula);
          if (newEl.hasAttribute("data-mathjax")) newEl.setAttribute("data-mathjax", newFormula);
          if (newEl.textContent === formula) {
            newEl.textContent = newFormula;
          }
          el.replaceWith(newEl);
          replaced = true;
        }
      }
    }

    while (true) {
      const text = getEditableSourceText(container);
      const ranges = findAllClozeRanges(text);
      if (!ranges.length) break;

      let next = ranges[0];
      for (let i = 1; i < ranges.length; i++) {
        if (ranges[i].openStart > next.openStart) {
          next = ranges[i];
        }
      }

      if (!unwrapClozeInContainerByBounds(container, next)) {
        break;
      }
      replaced = true;
    }

    return replaced;
  }

  function stripClozesFromHTML(html) {
    if (!html || !html.toLowerCase().includes("{{c")) return null;

    const tmpDiv = document.createElement("div");
    tmpDiv.innerHTML = html;
    if (!findAllClozeRanges(getEditableSourceText(tmpDiv)).length) {
      return null;
    }

    return removeAllClozesFromContainer(tmpDiv) ? tmpDiv.innerHTML : null;
  }

  function stripClozesFromText(text) {
    if (!text || !text.toLowerCase().includes("{{c")) return null;

    const tmpDiv = document.createElement("div");
    tmpDiv.textContent = text;
    if (!findAllClozeRanges(getEditableSourceText(tmpDiv)).length) {
      return null;
    }

    return removeAllClozesFromContainer(tmpDiv) ? (tmpDiv.textContent || "") : null;
  }

  function insertPasteReplacement(root, range, replacement) {
    const selection = getRootSelection(root);
    if (!selection) return false;

    selection.removeAllRanges();
    selection.addRange(range);

    if (Object.prototype.hasOwnProperty.call(replacement, "html")) {
      if (canUseCommand("insertHTML")) {
        document.execCommand("insertHTML", false, replacement.html);
        collapseSelectionToEnd(selection);
        return true;
      }

      range.deleteContents();
      const frag = range.createContextualFragment(replacement.html);
      const lastNode = frag.lastChild;
      range.insertNode(frag);
      if (lastNode) {
        range.setStartAfter(lastNode);
        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      return true;
    }

    if (canUseCommand("insertText")) {
      document.execCommand("insertText", false, replacement.text);
      collapseSelectionToEnd(selection);
      return true;
    }

    range.deleteContents();
    const textNode = document.createTextNode(replacement.text);
    range.insertNode(textNode);
    range.setStartAfter(textNode);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
    return true;
  }

  function handlePasteStripClozes(event) {
    if (event.defaultPrevented) return;

    const editable = getEditableFromEvent(event);
    if (!shouldStripPastedClozes(editable)) return;

    const clipboard = event.clipboardData || window.clipboardData;
    if (!clipboard || typeof clipboard.getData !== "function") return;

    const html = clipboard.getData("text/html") || "";
    const text = clipboard.getData("text/plain") || "";

    let replacement = null;
    const strippedHTML = stripClozesFromHTML(html);
    if (strippedHTML !== null) {
      replacement = { html: strippedHTML };
    } else {
      const strippedText = stripClozesFromText(text);
      if (strippedText === null) return;
      replacement = { text: strippedText };
    }

    const root = editable && editable.getRootNode ? editable.getRootNode() : getActiveRoot();
    const selection = getRootSelection(root);
    if (!selection || selection.rangeCount === 0) return;

    event.preventDefault();
    event.stopPropagation();

    const range = selection.getRangeAt(0).cloneRange();
    if (!insertPasteReplacement(root, range, replacement)) return;
    notifyInput(editable);
  }

  function installPasteHandlerIfNeeded() {
    if (window.__removeClozesPasteHandlerBound) return;

    document.addEventListener("paste", handlePasteStripClozes, true);
    window.__removeClozesPasteHandlerBound = true;
  }

  function replaceClozeByBounds(root, editable, bounds) {
    const { openStart, textStart, textEnd, closeEnd } = bounds;

    const startInfo = mapSourceIndexToNodeOffset(editable, openStart);
    
    const mathjax = getClosestMatchingNode(startInfo.node, "anki-mathjax");
    if (mathjax) {
      const formula = mathjax.getAttribute("data-formula") || mathjax.getAttribute("data-mathjax") || "";
      const source = getEditableSourceText(editable);
      const fullRepr = mathjax.classList.contains("mjx-block") 
                       ? "\\[" + formula + "\\]" 
                       : "\\(" + formula + "\\)";
      const mjIdx = source.indexOf(fullRepr, Math.max(0, openStart - fullRepr.length - 10));
      
      if (mjIdx !== -1) {
        const formulaContentStartInSource = mjIdx + 2;
        const relOpen = openStart - formulaContentStartInSource;
        const relText = textStart - formulaContentStartInSource;
        const relEnd = textEnd - formulaContentStartInSource;
        const relClose = closeEnd - formulaContentStartInSource;

        if (relOpen >= 0 && relClose <= formula.length) {
          const newFormula = formula.slice(0, relOpen) + 
                             formula.slice(relText, relEnd) + 
                             formula.slice(relClose);
          
          const newEl = mathjax.cloneNode(true);
          newEl.setAttribute("data-formula", newFormula);
          if (newEl.hasAttribute("data-mathjax")) newEl.setAttribute("data-mathjax", newFormula);
          if (newEl.textContent === formula) newEl.textContent = newFormula;

          const range = document.createRange();
          range.selectNode(mathjax);
          const sel = getRootSelection(root);
          sel.removeAllRanges();
          sel.addRange(range);

          if (canUseCommand("insertHTML")) {
            document.execCommand("insertHTML", false, newEl.outerHTML);
          } else {
            mathjax.replaceWith(newEl);
          }
          return true;
        }
      }
    }

    const innerStartPos = mapSourceIndexToNodeOffset(editable, textStart);
    const innerEndPos = mapSourceIndexToNodeOffset(editable, textEnd);
    const outerStartPos = mapSourceIndexToNodeOffset(editable, openStart);
    const outerEndPos = mapSourceIndexToNodeOffset(editable, closeEnd);

    const innerRange = document.createRange();
    innerRange.setStart(innerStartPos.node, innerStartPos.offset);
    innerRange.setEnd(innerEndPos.node, innerEndPos.offset);
    const innerFrag = innerRange.cloneContents();
    const tmpDiv = document.createElement("div");
    tmpDiv.appendChild(innerFrag);
    const innerHTML = tmpDiv.innerHTML;

    const outerRange = document.createRange();
    outerRange.setStart(outerStartPos.node, outerStartPos.offset);
    outerRange.setEnd(outerEndPos.node, outerEndPos.offset);

    const editSel = getRootSelection(root);
    if (!editSel) return false;
    editSel.removeAllRanges();
    editSel.addRange(outerRange);

    if (canUseCommand("insertHTML")) {
      document.execCommand("insertHTML", false, innerHTML);
      collapseSelectionToEnd(editSel);
    } else {
      outerRange.deleteContents();
      const frag = outerRange.createContextualFragment(innerHTML);
      outerRange.insertNode(frag);
      // Fallback caret positioning (simple)
      editSel.removeAllRanges();
    }

    return true;
  }

  function removeClozeAtCursor() {
    const root = getActiveRoot();
    const editable = getEditableDiv(root);
    if (!editable) return;

    if (editable.focus) editable.focus();

    const sel = root.getSelection ? root.getSelection() : document.getSelection();
    if (!sel || sel.rangeCount === 0) return;

    let range = sel.getRangeAt(0);

    // Collapse selection to start to avoid deleting parent cloze when nested
    if (!range.collapsed) {
      const tmp = range.cloneRange();
      tmp.collapse(true);
      sel.removeAllRanges();
      sel.addRange(tmp);
      range = tmp;
    }

    const pos = getCursorIndexInSource(editable, sel);
    if (pos < 0) return;

    const text = getEditableSourceText(editable);
    const bounds = findInnermostClozeAt(text, pos);
    if (!bounds) return;

    const replaced = replaceClozeByBounds(root, editable, bounds);
    if (!replaced) return;

    // Notify Anki
    notifyInput(editable);
  }

  function removeClozesInSelection() {
    const root = getActiveRoot();
    const editable = getEditableDiv(root);
    if (!editable) return;

    if (editable.focus) editable.focus();

    const sel = root.getSelection ? root.getSelection() : document.getSelection();
    if (!sel || sel.rangeCount === 0) return;

    let range = sel.getRangeAt(0);
    if (range.collapsed) {
      removeClozeAtCursor();
      return;
    }

    // Work on a detached fragment to preserve structure, then replace selection once.
    const frag = range.cloneContents();
    const tmpDiv = document.createElement("div");
    tmpDiv.appendChild(frag);

    if (!findAllClozeRanges(getEditableSourceText(tmpDiv)).length) {
      // No clozes fully inside the selection; fall back to cursor-based removal.
      removeClozeAtCursor();
      return;
    }

    const replaced = removeAllClozesFromContainer(tmpDiv);
    if (!replaced) return;

    const replacementHTML = tmpDiv.innerHTML;
    const editSel = getRootSelection(root);
    if (!editSel) return;
    editSel.removeAllRanges();
    editSel.addRange(range);

    if (canUseCommand("insertHTML")) {
      document.execCommand("insertHTML", false, replacementHTML);
      collapseSelectionToEnd(editSel);
    } else {
      range.deleteContents();
      const newFrag = range.createContextualFragment(replacementHTML);
      const lastNode = newFrag.lastChild;
      range.insertNode(newFrag);
      if (lastNode) {
        range.setStartAfter(lastNode);
        range.collapse(true);
        editSel.removeAllRanges();
        editSel.addRange(range);
      }
    }

    // Notify Anki
    notifyInput(editable);
  }

  // ==========================================
  // 9. EVENT LISTENERS & SETUP
  // ==========================================
  interceptWindowFunction("setClozeFields", function (fields) {
    editorClozeFields = Array.isArray(fields) ? fields.map(Boolean) : null;
  });

  // Public API expected by the add-on’s Python side and hotkey
  window.removeClozes = function () {
    removeClozesInSelection();
  };

  // Export internal functions for unit testing
  window._RemoveClozesTestAPI = {
    findAllClozeRanges,
    findInnermostClozeAt,
    getEditableSourceText,
    mapSourceIndexToNodeOffset,
    stripClozesFromHTML,
    stripClozesFromText,
    removeAllClozesFromContainer,
    replaceClozeByBounds,
  };

  installPasteHandlerIfNeeded();
  installReviewShortcutIfNeeded();
})();
